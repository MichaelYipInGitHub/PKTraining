var players=new Array(
    "轮空",
    "李风峰",
    "陈宇杰",
    "李灿威",
    "叶孟良",
    "唐振科",
    "周煜",
    "高薪博",
    "洪永祥",
    "林啸",
    "胡永乐",
    "吴健华",
    "陈子文",
    "倪仕萍",
    "张志敏",
    "李婷",
    "刘中付",
    "于皓",
    "洪健钧",
    "陈伟华",
    "杨江",
    "潘世杰",
    "陈健斌",
    "刘志艺",
    "梁志斌",
    "杜耀兴",
    "李玺迪",
    "吴子荣",
    "邝达明",
    "张睿",
    "莫坤浩",
    "林华",
    "曹俊贤",
    "邱佩诗",
    "苏结琼",
    "郑焙元",
    "许允生",
    "陈永亮",
    "李晶",
    "李健",
    "李毅贤",
    "林进森",
    "杨晓明",
    "周诗锐",
    "罗兆龙",
    "黎伟开",
    "谢智锋",
    "凌深",
    "刘骁",
    "许城玮",
    "黄弋毫",
    "焦杨",
    "苏振铭",
    "毛锋",
    "黄建勋",
    "郑满华",
    "李键敏",
    "梁佩琼",
    "卢浩斌",
    "翁晋",
    "刘柏昕");



var timer2;
var firstShoot;
var secondShoot;
var thirdShoot;



$(document).ready(function(){


    $("#start_btn").click(function(){
        var num = Math.floor(Math.random()*60)+1;
        $("#playerId").val(num);
            ready(num);
    });
    $("#end_btn").click(function(){
        document.getElementById('bibi').play();
        document.getElementById('gamming').pause();
        clearInterval(timer2);
        clearInterval(firstShoot);
        clearInterval(secondShoot);
        clearInterval(thirdShoot);
        $("#end_btn").hide();
        $("#again_btn").show();
        $("#restart_btn").show();
    });
    $("#restart_btn").click(function(){
        location.reload();
    });
    $("#again_btn").click(function(){
        $("#bottomShow").hide();
        $("#end_btn").hide();
        $("#again_btn").hide();
        $("#restart_btn").hide();
        $("#firstArrow").text("");
        $("#secondArrow").text("");
        $("#thirdArrow").text("");
        playAgain();
    });





});

function toPlay(num) {
    $("#playerId").val(num);
    ready(num);
}

function playAgain() {
    ready($("#playerId").val());
}

function ready(num){
    $("body").css("background-image","url()");
    // $("body").attr("background-image", "#");
    $("#player").attr("src", "img/opponent/"+num+".jpg");
    $("#playerName").text("对手："+players[num]);

    $("#pic_show").hide();
    $("#running_page").show();

    document.getElementById('palyer'+num).play();

    var _minutes = document.querySelectorAll('.minutes');
    var _seconds = document.querySelectorAll('.seconds');
    var seconds_ = 10;

    var timer = setInterval(function() {
        if (seconds_ >= 0) {
            minutes = Math.floor(seconds_ / 60);
            seconds = Math.floor(seconds_ % 60);
            minutes < 10 ? minutes = "0" + minutes : minutes = "" + minutes;
            seconds < 10 ? seconds = "0" + seconds : seconds = "" + seconds;
            setNumber(_minutes[0], Math.floor(minutes / 10), 1);
            setNumber(_minutes[1], minutes % 10, 1);
            setNumber(_seconds[0], Math.floor(seconds / 10), 1);
            setNumber(_seconds[1], seconds % 10, 1);

            if (seconds_ <= 60 || seconds_ == 0){
                $(".segment").css("background","red");
                $(".separator").css("background","red");
            }else{
                $(".segment").css("background","#00FF00");
                $(".separator").css("background","#00FF00");
            }
            --seconds_;
        } else {
            document.getElementById('bibi').play();
            clearInterval(timer);
            begin();
        }
    }, 1000);



    function begin(){

        document.getElementById('gamming').play();
        $("#bottomShow").show();
        $("#end_btn").show();
        var points=new Array("10","9");
        var score=new Array(points[Math.floor(Math.random()*10%2)],points[Math.floor(Math.random()*10%2)],points[Math.floor(Math.random()*10%2)]);


        var firstShootTime = Math.floor(Math.random()*20);
        firstShoot = setInterval(function() {
            if (firstShootTime >= 0) {
                --firstShootTime;
            } else {
                $("#firstArrow").text("对方第一箭："+score[0]+"环");
                if("10"==score[0]){
                    document.getElementById('first10').play();
                }else{
                    document.getElementById('first9').play();
                }
                clearInterval(firstShoot);
                var secondShootTime = Math.floor(Math.random()*20);
                secondShoot = setInterval(function() {
                    if (secondShootTime >= 0) {
                        --secondShootTime;
                    } else {
                        $("#secondArrow").text("对方第二箭："+score[1]+"环");
                        if("10"==score[1]){
                            document.getElementById('second10').play();
                        }else{
                            document.getElementById('second9').play();
                        }
                        clearInterval(secondShoot);
                        var thirdShootTime = Math.floor(Math.random()*20);
                        thirdShoot = setInterval(function() {
                            if (thirdShootTime >= 0) {
                                --thirdShootTime;
                            } else {
                                $("#thirdArrow").text("对方第三箭："+score[2]+"环");
                                if("10"==score[2]){
                                    document.getElementById('third10').play();
                                }else{
                                    document.getElementById('third9').play();
                                }
                                clearInterval(thirdShoot);
                            }
                        }, 1000);
                    }
                }, 1000);
            }
        }, 1000);





        var seconds2_ = 60;
        timer2 = setInterval(function() {
            if (seconds2_ >= 0) {
                minutes = Math.floor(seconds2_ / 60);
                seconds = Math.floor(seconds2_ % 60);
                minutes < 10 ? minutes = "0" + minutes : minutes = "" + minutes;
                seconds < 10 ? seconds = "0" + seconds : seconds = "" + seconds;
                setNumber(_minutes[0], Math.floor(minutes / 10), 1);
                setNumber(_minutes[1], minutes % 10, 1);
                setNumber(_seconds[0], Math.floor(seconds / 10), 1);
                setNumber(_seconds[1], seconds % 10, 1);

                if (seconds2_ <= 60 || seconds2_ == 0){
                    $(".segment").css("background","red");
                    $(".separator").css("background","red");
                }else{
                    $(".segment").css("background","#00FF00");
                    $(".separator").css("background","#00FF00");
                }
                --seconds2_;
            } else {
                document.getElementById('game_end').play();
                document.getElementById('gamming').pause();
                $("#end_btn").hide();
                $("#again_btn").show();
                $("#restart_btn").show();
                clearInterval(timer2);
            }
        }, 1000);
    }




}